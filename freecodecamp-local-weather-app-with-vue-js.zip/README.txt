A Pen created at CodePen.io. You can find this one at https://codepen.io/cmcoto/pen/QxWmme.

  Vue.js for the Local Weather App exercise on FreeCodeCamp, using Axios, and Bootstrap.